#include <iostream>

using namespace std;

extern "C" void get_input(char *buffer);

void get_input(char *buffer)
{
	cout << "Enter some HEX number: ";
	cin >> buffer;
}
