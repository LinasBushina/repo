﻿namespace SharpCompress.Crypto
{
    public interface ICipherParameters
    {
    }
}