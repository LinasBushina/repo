﻿namespace SharpCompress.Compressors
{
    public enum CompressionMode
    {
        Compress = 0,
        Decompress = 1
    }
}