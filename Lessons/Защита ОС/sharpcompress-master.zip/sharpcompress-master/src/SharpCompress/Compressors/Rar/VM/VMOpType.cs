namespace SharpCompress.Compressors.Rar.VM
{
    internal enum VMOpType
    {
        VM_OPREG = 0,
        VM_OPINT = 1,
        VM_OPREGMEM = 2,
        VM_OPNONE = 3
    }
}