namespace SharpCompress.Compressors.Rar.UnpackV1.PPM
{
    internal enum BlockTypes
    {
        BLOCK_LZ = 0,
        BLOCK_PPM = 1
    }
}