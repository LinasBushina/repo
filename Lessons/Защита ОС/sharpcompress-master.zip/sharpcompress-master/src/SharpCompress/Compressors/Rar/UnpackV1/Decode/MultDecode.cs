namespace SharpCompress.Compressors.Rar.UnpackV1.Decode
{
    internal class MultDecode : Decode
    {
        internal MultDecode()
            : base(new int[PackDef.MC20])
        {
        }
    }
}